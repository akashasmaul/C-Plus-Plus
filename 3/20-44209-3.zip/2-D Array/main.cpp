#include <iostream>
using namespace std;
/*
int main() {
   int transpose[4][3];

int a[3][4]={ 1,2,3,4,5,6,7,8,9,4,5,1};

   cout << "\nEntered Matrix: " << endl;
   for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 4; j++) {
         cout << " " << a[i][j];
         if (j == 4 - 1)
            cout << endl << endl;
      }
   }

   for (int i = 0; i < 3; i++)
      for (int j = 0; j < 4; j++) {
         transpose[j][i] = a[i][j];
      }

   cout << "\nTranspose of Matrix: " << endl;
   for (int i = 0; i < 4; i++)
      for (int j = 0; j < 3; j++) {
         cout << " " << transpose[i][j];
         if (j == 3 - 1)
            cout << endl << endl;
      }

}
*/

void encode(string s, int j)

{
    string result = "";

    for (int i=0;i<s.length();i++)
{
                result += (char)(s[i]+j);
   }
    cout << "Entered String : " << s;
    cout << "\nInteger: " << j;
    cout << "\nConverted String: " << result;
}


int main()
{
    encode("I am Akash", 2);
}

